package com.example.elsa10117252.model;

import com.google.android.gms.maps.model.LatLng;

/**
 * 10117252-Elsa Meilani on 11-08-2020.
 */

public class ModelMapLocation {

    public String name;
    public LatLng center;

    public ModelMapLocation() {}

    public ModelMapLocation(String name, double lat, double lng) {
        this.name = name;
        this.center = new LatLng(lat, lng);
    }
}
