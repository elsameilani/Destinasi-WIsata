package com.example.elsa10117252.api;

public class Api {

    public static String Kuliner = "https://dev.farizdotid.com/api/purwakarta/kuliner";
    public static String DetailKuliner = "https://dev.farizdotid.com/api/purwakarta/kuliner/{id}";
    public static String Wisata = "https://dev.farizdotid.com/api/purwakarta/wisata";
    public static String DetailWisata = "https://dev.farizdotid.com/api/purwakarta/wisata/{id}";
}
