package com.example.elsa10117252.model;

/**
 * 10117252-Elsa Meilani on 11-08-2020.
 */

public class ModelMain {

    private String txtName;
    private int imgSrc;

    public ModelMain(String txtName, int imgSrc) {
        this.txtName = txtName;
        this.imgSrc = imgSrc;
    }

    public String getTxtName() {
        return txtName;
    }

    public void setTxtName(String txtName) {
        this.txtName = txtName;
    }

    public int getImgSrc() {
        return imgSrc;
    }

    public void setImgSrc(int imgSrc) {
        this.imgSrc = imgSrc;
    }

}
